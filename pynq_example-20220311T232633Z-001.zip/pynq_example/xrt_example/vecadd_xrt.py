import numpy as np
import pynq
# from pynq import Xlnk
# from pynq import Overlay
# from pynq import allocate

# # used in PYNQ v2.4 or older
# xlnk = Xlnk()
# xlnk.xlnk_reset()

print(f'Using PYNQ version: {pynq.__version__}')

overlay = pynq.Overlay("vecadd.xclbin") # or *.awsxclbin file on AWS F1
vecadd_inst = overlay.pl_vecadd_u250_1  # modify this to real inst name

print("Bitstream loaded")

# only supported in PYNQ v2.5 and newer
array_a = pynq.allocate(shape=(1024,), dtype=np.float32)
array_b = pynq.allocate(shape=(1024,), dtype=np.float32)
array_c = pynq.allocate(shape=(1024,), dtype=np.float32)

# Supported in PYNQ v2.4 or older
# array_a = xlnk.cma_array(shape=(1024,), dtype=np.float32)
# array_b = xlnk.cma_array(shape=(1024,), dtype=np.float32)
# array_c = xlnk.cma_array(shape=(1024,), dtype=np.float32)


for i in range(1024):
    array_a[i] = float(i)
    array_b[i] = float(i)
    array_c[i] = 0.0

# sync_to_device() only supported in PYNQ v2.5 and newer
array_a.sync_to_device()
array_b.sync_to_device()
array_c.sync_to_device()

# # Supported in PYNQ v2.4 or older
# array_a.flush()
# array_b.flush()
# array_c.flush()

# vecadd_inst.write(0x10, array_a.physical_address)
# vecadd_inst.write(0x1c, array_b.physical_address)
# vecadd_inst.write(0x28, array_c.physical_address)

print('finish preparing arrays, starting accelerator...')

vecadd_inst.call(array_a, array_b, array_c)
# handle = vecadd_inst.start(array_a, array_b, array_c)
# handle.wait()

# vecadd_inst.write(0x00, 1)
# isready = vecadd_inst.read(0x00)
# while( isready == 1 ):
#     isready = vecadd_inst.read(0x00)

print('accelerator done')

# sync_to_device() only supported in PYNQ v2.5 and newer
array_a.sync_from_device()
array_b.sync_from_device()
array_c.sync_from_device()

# # Supported in PYNQ v2.4 or older
# array_a.invalidate()
# array_b.invalidate()
# array_c.invalidate()

for i in range(10):
    print(f'array_a[{i}] = {array_a[i]}')
for i in range(10):
    print(f'array_b[{i}] = {array_b[i]}')
for i in range(10):
    print(f'array_c[{i}] = {array_c[i]}')

array_a.close()
array_b.close()
array_c.close()
