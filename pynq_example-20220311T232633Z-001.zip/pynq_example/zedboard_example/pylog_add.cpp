int pylog_add(float a[1024], float b[1024], float c[1024])
{
  #pragma HLS INTERFACE m_axi port=a offset=slave bundle=DATA_0
  #pragma HLS INTERFACE m_axi port=b offset=slave bundle=DATA_1
  #pragma HLS INTERFACE m_axi port=c offset=slave bundle=DATA_2
  #pragma HLS INTERFACE s_axilite register port=return bundle=CTRL
  for (int i = 0; i < 1024; i += 1)
  {
    #pragma HLS pipeline
    c[i] = a[i] + b[i];
  }

  return 0;
}

