#include "ap_int.h"
const int NT = 10;
void krnl_transfer(int* in,int* out, const int size );
 
